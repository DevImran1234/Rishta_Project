import React from 'react';
import './MarriageForm.css';
import logo from '../../images/white.png';
import Rectangle25 from '../../images/Rectangle 25.png';
import Rectangle24 from '../../images/Rectangle 24.png';
import marriage from '../../images/marriage.png';
import flowers from '../../images/flowers.png';

const MarriageForm = () => {
  return (
    <div className="marriage-form-container">
      <img src={logo} alt="Logo" className="logo" style={{ marginLeft: '15px' }} />
      <div className="form-left">
        <div className="slider">
          <img src={Rectangle25} alt="Rectangle" className="rectangle rectangle1" />
          <img src={Rectangle24} alt="Rectangle" className="rectangle rectangle2" />
        </div>
        <img src={marriage} alt="Marriage" className="marriage-img" />
        <img src={flowers} alt="Flowers" className="flowers-img" />
      </div>
    </div>
  );
}

export default MarriageForm;
